/*BEGIN_LEGAL
This Software is part of Intel(R) SAE. The rights to copy, distribute,
modify, or otherwise make use of this Software may be licensed only
pursuant to the terms of an applicable Intel license agreement.

Copyright 2010-2016 Intel(R) Corporation
END_LEGAL */

#include <iostream>
#include <map>

#include "ztool-api.h"

using namespace std;

// Init function. Called by zsim.
extern "C" void ztool_init(ztool_init_handle_t handle)
{
}
